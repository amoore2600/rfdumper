Acknowledgments:

  This program uses the zlib library by Jean-loup Gailly and Mark Adler.
  Visit http://www.zlib.net or read the ZlibReadme.txt for more information.
  This program also uses code snipes provided by Hyperkin http://hyperkin.com

Copyright notice:

 (C) 2015 Wolfgang Graulich

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.
  
Installation notes:
  This program requires Microsoft ASP .NET MVC 4 Runtime 
  https://www.microsoft.com/en-US/download/details.aspx?id=17718 
  and Microsoft Visual C++ 2010 Redistributable.
  https://www.microsoft.com/en-US/download/details.aspx?id=8328